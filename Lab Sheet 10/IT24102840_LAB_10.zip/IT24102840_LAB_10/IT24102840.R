setwd("C://Users//USER//Desktop//IT24102840_LAB_10")

snack_observed <- c(120, 95, 85, 100)
snack_names <- c("A", "B", "C", "D")
snack_prob <- c(0.25, 0.25, 0.25, 0.25)


snack_data <- data.frame(
  Snack_Type = snack_names,
  Count = snack_observed
)

print(snack_data)

snack_test <- chisq.test(x = snack_observed, p = snack_prob)


print(snack_test)


if (snack_test$p.value < 0.05) {
  cat("Since p-value (", round(snack_test$p.value, 4), ") < 0.05, reject H0.\n")
  cat("Evidence suggests snack preferences are NOT equal.\n")
} else {
  cat("Since p-value (", round(snack_test$p.value, 4), ") > 0.05, do not reject H0.\n")
  cat("No evidence that snack preferences are different.\n")

