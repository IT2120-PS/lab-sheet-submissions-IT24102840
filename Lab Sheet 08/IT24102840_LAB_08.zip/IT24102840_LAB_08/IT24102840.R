setwd("C:\\Users\\it24102840\\Desktop\\IT24102840_LAB_08")

data <- read.table("C:\\Users\\it24102840\\Desktop\\IT24102840_LAB_08\\Exercise - LaptopsWeights.txt", header = TRUE)
fix(data)
attach(data)

##Exercise Question 01

popmean <- mean(Weight.kg.)
popsd <- sd(Weight.kg.)

popmean
popsd

##Exercise Question 02

samples <- c()
n <- c()

for(i in 1:25) {
  s <- sample(Weight.kg., 6, replace = TRUE)
  samples <- cbind(samples, s)
  n <- c(n, paste('S', i))
}

colnames(samples) <- n

s.means <- apply(samples, 2, mean)
s.sds <- apply(samples, 2, sd)

results <- data.frame(Sample = n, Mean = s.means, Standard_Deviation = s.sds)
results

##Exercise Question 03

mean_of_means <- mean(s.means)
sd_of_means <- sd(s.means)

mean_of_means
sd_of_means

theoretical_sd <- popsd / sqrt(6)

popmean
mean_of_means

popsd
theoretical_sd
sd_of_means

summary_table <- data.frame(
  Parameter = c("Population Mean", 
                "Population Standard Deviation", 
                "Mean of Sample Means", 
                "Standard Deviation of Sample Means",
                "Theoretical Standard Error (σ/√6)"),
  Value = c(popmean, popsd, mean_of_means, sd_of_means, theoretical_sd)
)

summary_table
